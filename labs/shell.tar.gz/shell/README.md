This is a simple shell written in C.

Unit tests are written using the bandit framework requiring C++.

Requirements
============

- make
- C99 for the C code
- GNU readline and history libraries, development files
- C++14 for the test code
- bandit (only for testing, git clone --recurse-submodules https://github.com/banditcpp/bandit)
