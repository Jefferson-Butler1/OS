#include <bandit/bandit.h>

using namespace snowhouse;
using namespace bandit;

int main(int argc, char *argv[]) {
    return bandit::run(argc, argv);
}
